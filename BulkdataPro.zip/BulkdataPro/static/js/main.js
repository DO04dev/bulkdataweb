$( document ).ready(function() {
    $(".dropdown-trigger").dropdown({ hover: true });
    $('.sidenav').sidenav();
});